#!/bin/sh

rm -vrf ./hijack/libs ./hijack/obj ./instruments/base/obj ./instruments/example/libs ./instruments/example/obj
